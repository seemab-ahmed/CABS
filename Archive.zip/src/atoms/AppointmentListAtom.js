import { atom } from 'recoil';

export const appointmentListAtom = atom({
  key: 'appointmentListAtom',
  default: [],
});