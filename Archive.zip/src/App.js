

function App () {
  return (
    <>Hello Clinic Management system</>
  );
}

export default App;
